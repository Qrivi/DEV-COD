import Vector from './classes/Vector.js';
import Player from './classes/Player.js';
import Ball from './classes/Ball.js';
import CollisionDetector from './classes/CollisionDetector.js';

{
    let canvas, ctx;
    let mouse;
    let player, ball;
    let playing;
    let collisionDetector;

    const init = () => {
        console.log( `JavaScript is in the house. 🎉` );
        canvas = document.getElementById( `canvas` );
        ctx = canvas.getContext( `2d` );

        if( !ctx )
            return;

        mouse = new Vector( canvas.width / 2, canvas.height / 2 );
        player = new Player( canvas.width / 2, canvas.height, `yellow` );
        ball = new Ball( canvas.width / 2, canvas.height / 2, `red` );
        playing = false;

        collisionDetector = new CollisionDetector();
        collisionDetector.on( `collision`, handleCollision );

        canvas.addEventListener( `mousemove`, mousemove );
        canvas.addEventListener( `click`, mouseclick );

        draw();
    };

    const reset = () => {
        ball = new Ball( canvas.width / 2, canvas.height / 2, `red` );
        playing = false;
    };

    const mousemove = event => {
        mouse.x = event.clientX;
        mouse.y = event.clientY;
    };

    const mouseclick = event => {
        playing = true;
    };

    const handleCollision = ( player, ball ) => {
        ball.bounce( `bottom` );
    };

    const draw = () => {
        ctx.fillStyle = `black`;
        ctx.fillRect( 0, 0, canvas.width, canvas.height );

        player.move( mouse.x );
        player.draw( ctx );

        if( ball.location.x > canvas.width )
            ball.bounce( `right` );
        if( ball.location.x < 0 )
            ball.bounce( `left` );
        if( ball.location.y < 0 )
            ball.bounce( `top` );
        if( ball.location.y > canvas.height )
            reset();
        if( playing )
            ball.move();
        ball.draw( ctx );

        collisionDetector.detectCollisions( player, ball );
        window.requestAnimationFrame( draw );
    };

    init();
}
