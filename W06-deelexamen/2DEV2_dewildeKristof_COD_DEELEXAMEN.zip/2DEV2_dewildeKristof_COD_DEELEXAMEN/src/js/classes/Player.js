import GameObject from './GameObject.js';

export default class Player extends GameObject {
    constructor( x, y, color ) {
        super( x, y, color );
        this.width = 120;
    };

    move( position ) {
        this.location.x = position;
    };

    draw( ctx ) {
        ctx.save();
        ctx.translate( this.location.x - this.width / 2, this.location.y - this.height );

        ctx.fillStyle = this.color;

        ctx.beginPath();
        ctx.moveTo( this.width / 2, 0 );
        ctx.arcTo( this.width, 0, this.width, this.height, Math.min( this.height / 2, this.radius ) );
        ctx.arcTo( this.width, this.height, 0, this.height, Math.min( this.width / 2, this.radius ) );
        ctx.arcTo( 0, this.height, 0, 0, Math.min( this.height / 2, this.radius ) );
        ctx.arcTo( 0, 0, this.radius, 0, Math.min( this.width / 2, this.radius ) );
        ctx.lineTo( this.width / 2, 0 );
        ctx.fill();

        ctx.restore();
    };
}
