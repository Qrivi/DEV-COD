import Vector from './Vector.js';

export default class GameObject {
    constructor( x, y, color ) {
        this.location = new Vector( x, y );
        this.velocity = new Vector( 0, 0 );
        this.color = color;

        this.width = this.height = 20;
        this.radius = this.height / 2;
    };

    calculateDistanceToContainer( otherElement ) {
        let thisBiggestSide = Math.max( this.width, this.height );
        let otherBiggestSide = Math.max( otherElement.width, otherElement.height );

        return Vector.sub( otherElement.location, this.location )
            .mag() - otherBiggestSide / 2 - thisBiggestSide / 2;
    };

    calculateVerticalOffset( otherElement ) {
        return this.location.y - otherElement.location.y;
    };

    collidesWith( otherElement ) {
        return( this.calculateDistanceToContainer( otherElement ) <= 0 &&
            this.calculateVerticalOffset( otherElement ) <= this.height );
    };
}
