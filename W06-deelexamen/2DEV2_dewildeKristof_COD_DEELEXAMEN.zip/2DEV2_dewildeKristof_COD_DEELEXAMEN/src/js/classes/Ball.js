import GameObject from './GameObject.js';
import Vector from './Vector.js';
import { random } from '../functions/lib.js';

export default class Ball extends GameObject {
    constructor( x, y, color ) {
        super( x, y, color );

        let dir = random( -1, 1 ) > 0 ? 1 : -1;
        let angle = random( 2, 8 );

        this.velocity = new Vector( 2.5 * dir, angle );
    };

    bounce( side ) {
        switch( side ) {
            case `top`:
                this.velocity.y = Math.abs( this.velocity.y );
                break;
            case `right`:
                this.velocity.x = -Math.abs( this.velocity.x );
                break;
            case `bottom`:
                this.velocity.y = -Math.abs( this.velocity.y );
                break;
            case `left`:
                this.velocity.x = Math.abs( this.velocity.x );
                break;
        }
    };

    move() {
        this.location.add( this.velocity );
    }

    draw( ctx ) {
        ctx.save();
        ctx.translate( this.location.x - this.radius / 2, this.location.y - this.radius / 2 );

        ctx.fillStyle = this.color;

        ctx.beginPath();
        ctx.arc( 0, 0, this.radius, 0, 2 * Math.PI );
        ctx.fill();

        ctx.restore();
    };
}
