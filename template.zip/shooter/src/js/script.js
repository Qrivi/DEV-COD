import Vector from './classes/Vector.js';
import { loadImage } from './functions/lib.js';

const canvas = document.getElementById(`canvas`),
    ctx = canvas.getContext(`2d`);;

const init = () => {
    console.log(`Hello World!`);
};

init();
